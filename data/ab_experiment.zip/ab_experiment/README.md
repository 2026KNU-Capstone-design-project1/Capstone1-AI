# 비교 실험(A~D) 입력 파일

- 대상: 위험 상태 모델 test 세트 **1,256장** (위험 575장 + 정상 681장)
  - 시설물 위험 범위 밖(SO · C 코드, 작업자 관련 N 코드)은 학습 때와 같이 제외
- 세 파일 모두 `{"meta": {...}, "items": [...]}` 형식, `image_id`(사진 파일 이름)로 서로 연결
- 모델: 위험 상태 YOLO11n(45종), 객체 YOLO11n(73종) / 사람은 신호수만 포함 (AI 서버와 같은 설정)

## 1. gt_labels.json — 정답
| 필드 | 뜻 |
|---|---|
| image_id | 사진 ID |
| hazard_code | 정답 위험 코드 (정상 사진이면 null) |
| situation_code | 원본 상황 코드 (N-xx 위험 / Y-xx 정상) |
| hazard_name | 위험 이름 |
| is_hazard | 실제 위험 여부 (true / false) |
| gt_bbox | 정답 위험 박스 (0~1 비율, x · y = 왼쪽 위) |

## 2. yolo_predictions.json — YOLO 위험 탐지 예측 (A 입력)
| 필드 | 뜻 |
|---|---|
| image_id | 사진 ID |
| predictions[] | 탐지 결과 목록 (없으면 빈 목록) |
| ├ hazard_code / hazard_name | 예측 위험 코드 / 이름 |
| ├ confidence | 신뢰도 |
| ├ bbox | 예측 박스 (0~1 비율) |
| └ area_ratio | 박스 넓이 / 화면 넓이 (관측 품질 검사용) |

- **confidence 0.25 이상을 전부 저장** → 실험에서 기준값(0.3 / 0.5 / 0.7 등)으로 걸러서 사용
- AI 서버는 0.5 이상을 위험으로 판단

## 3. spatial_judgments.json — 공간관계 판단 (B 입력)
| 필드 | 뜻 |
|---|---|
| image_id | 사진 ID |
| evaluation_status / reason_code | 장면 요약 판단 / 원인 |
| checks[] | 위험별 판단: hazard_code, status, reason_code, agrees_with_model, detected_by_model, (missing, gap) |
| findings[] | 규칙이 찾은 위험 (YOLO와 무관하게 공간관계 규칙만으로 판단) |
| objects[] | 객체 탐지 결과 (code, name, confidence, bbox) |
| gt_code_check_for_analysis_only | **분석용** — 정답 위험 코드에 대해 규칙이 어떻게 판단했는지. **예측 입력으로 쓰면 안 됨 (정답 누설)** |

- status: hazard(규칙이 위험 확인) / no_hazard(조건 불충족) / not_evaluable(판단 불가)
- reason_code: rule_matched / condition_not_met / rule_not_supported / missing_objects / insufficient_evidence
- agrees_with_model: YOLO와 규칙 판단 일치(true) / 불일치(false) / 비교 불가(null)
- **checks 는 YOLO confidence 0.25 이상 예측 기준**으로 만들어짐 → 기준값을 높이면 그 기준 아래 예측의 check 는 무시하고, 규칙 판단은 findings 를 기준으로 보면 됨

## 참고 수치 (확인용)
- A(YOLO 그대로, confidence ≥ 0.5): 위험 사진 중 정답 코드 탐지 465 / 575 (0.809), 정상 사진 오경보 16 / 681 (0.023)
- 정답 위험 코드에 대한 규칙 판단 원인: rule_matched 380 / rule_not_supported 130 / missing_objects 41 / condition_not_met 24
  → 위험 사진의 약 23%는 해당 위험에 규칙이 없음 (B 단독 판단 시 누락으로 이어질 수 있음)
