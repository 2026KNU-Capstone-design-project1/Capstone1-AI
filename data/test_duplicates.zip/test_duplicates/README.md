# test ↔ train 유사 이미지 목록

## 판정 방법
- 사진 지문 dHash(64비트)로 test 1,537장과 train 7,175장을 모두 비교
- 해밍 거리 6 이하(유사도 90.6% 이상)를 유사 후보로 보고, 이미지 ID로 유형을 나눔

| match_type | 뜻 | 성능 재계산 시 |
|---|---|---|
| duplicate | 같은 날짜·장소 + 같은 상황 코드 → **사실상 중복** | **제외 대상** |
| normal_abnormal | 같은 날짜·장소의 정상(Y) ↔ 비정상(N) 쌍 (정답이 반대, 배경만 같음) | 유지 권장 |
| same_site_other | 같은 날짜·장소, 다른 상황 코드 | 유지 권장 |
| false_match | 장소가 다름 (어두운 사진 등 지문이 우연히 비슷한 오탐) | 유지 |

## 결과
| 유형 | 전체 test 1,537장 | A~D 실험 1,256장 |
|---|---|---|
| duplicate | 64장 (4.2%) | **53장 (4.2%)** — 위험 30 / 정상 23 |
| normal_abnormal | 15장 (1.0%) | 15장 (1.2%) |
| same_site_other | 10장 (0.7%) | 9장 (0.7%) |
| false_match | 64장 (4.2%) | 34장 (2.7%) |

## 파일
| 파일 | 내용 |
|---|---|
| duplicate_test_ids_in_1256.txt | **A~D 실험 1,256장 중 사실상 중복 test 이미지 ID 53개** (한 줄에 하나) |
| test_images_with_similar_train.csv | test 이미지별 가장 대표적인 유사 train 이미지 1개 (유형 우선순위: duplicate > normal_abnormal > same_site_other > false_match) |
| test_train_similar_pairs.csv | 유사 판정된 모든 (test, train) 쌍 |

CSV 열: test_image_id, (closest_)train_image_id, hamming_distance, similarity_pct, match_type, (test/train_situation_code), in_ab_experiment_1256

## 참고 (확인용)
- A(YOLO 그대로, confidence ≥ 0.5): 전체 1,256장 재현율 0.809 / 오경보율 0.023
  → 중복 53장 제외 1,203장: 재현율 0.798 / 오경보율 0.024 (차이 작음)
- dHash 는 작은 흑백 썸네일 비교라 정밀하지 않음 → 유형 분류는 이미지 ID(날짜·장소·상황 코드) 기준으로 보정함
